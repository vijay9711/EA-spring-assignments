package bank.integration.jms;

public interface JMSSender {
	void sendJMSMessage (String text);
}
