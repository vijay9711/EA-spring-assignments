package customers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class ProductRespository {

    @Autowired
    private NamedParameterJdbcTemplate jdbcTemplate;

    public void clearDB() {
        Map<String,Object> namedParameters = new HashMap<String,Object>();
        jdbcTemplate.update("DELETE from product",namedParameters);
        jdbcTemplate.update("DELETE from supplier",namedParameters);
    }

    public void save(Product product){
        Map<String,Object> namedParameters = new HashMap<String,Object>();
        namedParameters.put("productnumber", product.getProductNumber());
        namedParameters.put("name", product.getName());
        namedParameters.put("phone", product.getPrice());
        jdbcTemplate.update("INSERT INTO product VALUES (:productnumber, :name, :phone)",namedParameters);

        // save supplier
        Map<String,Object> namedParameterscc = new HashMap<String,Object>();
        namedParameterscc.put("suppliernumber", product.getSupplier().getSupplierID());
        namedParameterscc.put("productnumber", product.getProductNumber());
        namedParameterscc.put("name", product.getSupplier().getName());
        namedParameterscc.put("phone", product.getSupplier().getPhone());
        jdbcTemplate.update("INSERT INTO supplier VALUES (:suppliernumber, :productnumber, :name, :phone)",namedParameterscc);
    }
    public Product getProductById(int productnumber){
        Map<String,Object> namedParameters = new HashMap<String,Object>();
        namedParameters.put("productnumber", productnumber);
        Product product = jdbcTemplate.queryForObject("SELECT * FROM product WHERE "
                        + "productnumber =:productnumber ",
                namedParameters,
                (rs, rowNum) -> new Product( rs.getInt("productnumber"),
                        rs.getString("name"),
                        rs.getInt("price")));

        Supplier supplier = getSupplierForProduct(product.getProductNumber());
        product.setSupplier(supplier);
        return product;
    }

    Supplier getSupplierForProduct(int productnumber){
        Map<String,Object> namedParameters = new HashMap<String,Object>();
        namedParameters.put("productnumber", productnumber);
        Supplier supplier = jdbcTemplate.queryForObject("SELECT * FROM supplier WHERE "
                        + "productnumber =:productnumber ",
                namedParameters,
                (rs, rowNum) -> new Supplier( rs.getInt("suppliernumber"),
                        rs.getString("name"),
                        rs.getString("phone")));

        return supplier;
    }

    public List<Product> getAllProducts(){
        List<Product> products = jdbcTemplate.query("SELECT * FROM product",
                new HashMap<String, Product>(),
                (rs, rowNum) -> new Product( rs.getInt("productNumber"),
                        rs.getString("name"),
                        rs.getInt("price")));

        for (Product product: products){
            Supplier supplier = getSupplierForProduct(product.getProductNumber());
            product.setSupplier(supplier);
        }
        return products;
    }

    public Product getProductByName(String productName) {
        Map<String, Object> namedParameters = new HashMap<>();
        namedParameters.put("productName", productName);
        Product product = jdbcTemplate.queryForObject(
                "SELECT * FROM product WHERE name = :productName",
                namedParameters,
                (rs, rowNum) -> new Product(
                        rs.getInt("productnumber"),
                        rs.getString("name"),
                        rs.getInt("price")
                )
        );
        Supplier supplier = getSupplierForProduct(product.getProductNumber());
        product.setSupplier(supplier);
        return product;
    }

    public void removeProduct(int productNumber) {
        Map<String, Object> namedParameters = new HashMap<>();
        namedParameters.put("productNumber", productNumber);
        jdbcTemplate.update("DELETE FROM product WHERE productnumber = :productNumber", namedParameters);
    }
}
