package customers;

public class Supplier {
    private int supplierID;
    private String name;
    private String phone;
    private Supplier supplier;
    public Supplier(int supplierID, String name, String phone){
        this.supplierID = supplierID;
        this.name = name;
        this.phone = phone;
    }

    @Override
    public String toString() {
        return "Supplier {" +
                "supplierID=" + supplierID +
                ", name='" + name + '\'' +
                ", phone='" + phone + '\'' +
                '}';
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public int getSupplierID() {
        return supplierID;
    }

    public void setSupplierID(int supplierID) {
        this.supplierID = supplierID;
    }

    public void setSupplier(Supplier supplier) {
        this.supplier = supplier;
    }

    public Supplier getSupplier() {
        return supplier;
    }
}
