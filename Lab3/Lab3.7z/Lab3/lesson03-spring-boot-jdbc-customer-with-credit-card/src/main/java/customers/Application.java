package customers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Application implements CommandLineRunner {

	@Autowired
	private CustomerRepository customerRepository;

	@Autowired
	private ProductRespository productRespository;

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		customerRepository.clearDB();
		productRespository.clearDB();
		Customer customer = new Customer(101,"John doe", "johnd@acme.com", "0622341678");
		CreditCard creditCard = new CreditCard("12324564321", "Visa", "11/23");
		customer.setCreditCard(creditCard);
		customerRepository.save(customer);
		customer = new Customer(66,"James Johnson", "jj123@acme.com", "068633452");
		creditCard = new CreditCard("99876549876", "MasterCard", "01/24");
		customer.setCreditCard(creditCard);
		customerRepository.save(customer);

//		add product
		Product product = new Product(123, "Pen", 2);
		Supplier supplier = new Supplier(111, "Kim", "87564783837");
		product.setSupplier(supplier);

		Product product1 = new Product(133, "Pencil", 4);
		Supplier supplier1 = new Supplier(131, "Tom", "87564783837");
		product1.setSupplier(supplier1);
		productRespository.save(product);
		productRespository.save(product1);

		System.out.println("----------- product by id ----------------");
		System.out.println(productRespository.getProductById(123));
		System.out.println(productRespository.getProductByName("Pen"));
		System.out.println("-----------All products ----------------");
		System.out.println(productRespository.getAllProducts());
		productRespository.removeProduct(123);
		System.out.println("-----------All products after remove product 123 ----------------");
		System.out.println(productRespository.getAllProducts());

		System.out.println("----------- customers ----------------");
		System.out.println(customerRepository.getCustomer(101));
		System.out.println(customerRepository.getCustomer(66));
		System.out.println("-----------All customers ----------------");
		System.out.println(customerRepository.getAllCustomers());

	}

}
