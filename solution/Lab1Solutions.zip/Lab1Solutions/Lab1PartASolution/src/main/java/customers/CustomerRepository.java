package customers;

public interface CustomerRepository {

	void save(Customer customer) ;

}
