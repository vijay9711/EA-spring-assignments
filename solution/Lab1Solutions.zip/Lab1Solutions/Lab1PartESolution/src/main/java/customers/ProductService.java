package customers;

public interface ProductService {

	void addProduct(String description, Double price, String email);

}
