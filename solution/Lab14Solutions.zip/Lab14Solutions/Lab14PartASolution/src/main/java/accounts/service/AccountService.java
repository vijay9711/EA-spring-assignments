package accounts.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import accounts.domain.Account;
import accounts.repository.AccountRepository;

@Service
public class AccountService {

	@Autowired
	AccountRepository accountRepository;
		
	public AccountResponse getAccount(String acountNumber) {
		Optional<Account> accountOptional = accountRepository.findById(acountNumber);
		if (accountOptional.isPresent()) {
			Account account = accountOptional.get();
			AccountResponse accountDto = AccountAdapter.getAccountDto(account);
			return accountDto;
		}
		return null;
	}
	
	public void createAccount(String accountNumber, double amount, String accountHolder) {
		accountRepository.save(new Account(accountNumber, amount, accountHolder));
	}
	

}
