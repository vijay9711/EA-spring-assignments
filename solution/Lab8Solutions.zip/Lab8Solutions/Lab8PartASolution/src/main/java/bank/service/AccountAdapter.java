package bank.service;

import bank.domain.Account;
import bank.domain.AccountEntry;

import java.util.ArrayList;
import java.util.List;

public class AccountAdapter {

    public static Account getAccountFromAccountResponse(AccountResponse accountResponse){
        Account account = new Account();
        account.setAccountnumber(accountResponse.getAccountnumber());
        account.setCustomer(CustomerAdapter.getCustomerFromCustomerResponse(accountResponse.getCustomer()));
        for (AccountEntryResponse accountEntryResponse : accountResponse.getEntryList()){
            account.getEntryList().add(AccountEntryAdapter.getAccountEntryFromAccountEntryResponse(accountEntryResponse));
        }
        return account;
    }

    public static AccountResponse getAccountResponseFromAccount(Account account){
        AccountResponse accountDto = new AccountResponse();
        accountDto.setAccountnumber(account.getAccountnumber());
        accountDto.setBalance(account.getBalance());
        accountDto.setCustomer(CustomerAdapter.getCustomerResponseFromCustomer(account.getCustomer()));
        for (AccountEntry accountEntry : account.getEntryList()){
            accountDto.getEntryList().add(AccountEntryAdapter.getAccountEntryResponseFromAccountEntry(accountEntry));
        }
        return accountDto;
    }

    public static List<AccountResponse> getAccountResponseListFromAccountList(List<Account> accountList){
        List<AccountResponse> accountResponseList = new ArrayList<>();
        for (Account account : accountList){
            accountResponseList.add(getAccountResponseFromAccount(account));
        }
        return accountResponseList;
    }
}
