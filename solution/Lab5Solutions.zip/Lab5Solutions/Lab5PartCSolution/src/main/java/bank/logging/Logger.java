package bank.logging;

public interface Logger {
    public void log (String logstring);
}
