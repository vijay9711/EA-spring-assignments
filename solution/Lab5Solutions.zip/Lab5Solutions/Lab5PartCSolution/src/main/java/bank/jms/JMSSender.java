package bank.jms;

public interface JMSSender {
	public void sendJMSMessage (String text);
}
