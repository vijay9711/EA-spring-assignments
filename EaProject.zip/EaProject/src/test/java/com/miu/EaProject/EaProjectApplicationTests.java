package com.miu.EaProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EaProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
