package bank.controller;

import bank.service.AccountResponse;
import bank.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Collection;

@RestController
@RequestMapping("/bank/accounts")
public class AccountController {

    @Autowired
    private AccountService accountService;

    @PostMapping
    public ResponseEntity<AccountResponse> createAccount(@RequestParam long accountNumber, @RequestParam String customerName) {
        AccountResponse accountResponse = accountService.createAccount(accountNumber, customerName);
        return new ResponseEntity<>(accountResponse, HttpStatus.CREATED);
    }

    @GetMapping("/{accountNumber}")
    public ResponseEntity<AccountResponse> getAccount(@PathVariable long accountNumber) {
        AccountResponse accountResponse = accountService.getAccount(accountNumber);
        return new ResponseEntity<>(accountResponse, HttpStatus.OK);
    }

    @GetMapping
    public ResponseEntity<Collection<AccountResponse>> getAllAccounts() {
        Collection<AccountResponse> accountResponses = accountService.getAllAccounts();
        return new ResponseEntity<>(accountResponses, HttpStatus.OK);
    }

    @PostMapping("/{accountNumber}/deposit")
    public ResponseEntity<Void> deposit(@PathVariable long accountNumber, @RequestParam double amount) {
        accountService.deposit(accountNumber, amount);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @PostMapping("/{accountNumber}/withdraw")
    public ResponseEntity<Void> withdraw(@PathVariable long accountNumber, @RequestParam double amount) {
        accountService.withdraw(accountNumber, amount);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @PostMapping("/{fromAccountNumber}/transfer")
    public ResponseEntity<Void> transferFunds(@PathVariable long fromAccountNumber, @RequestParam long toAccountNumber,
                                              @RequestParam double amount, @RequestParam String description) {
        accountService.transferFunds(fromAccountNumber, toAccountNumber, amount, description);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @PostMapping("/{accountNumber}/depositEuros")
    public ResponseEntity<Void> depositEuros(@PathVariable long accountNumber, @RequestParam double amount) {
        accountService.depositEuros(accountNumber, amount);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @PostMapping("/{accountNumber}/withdrawEuros")
    public ResponseEntity<Void> withdrawEuros(@PathVariable long accountNumber, @RequestParam double amount) {
        accountService.withdrawEuros(accountNumber, amount);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
