package bank.integration.logging;

public interface Logger {
    void log (String logstring);
}
