import books.domain.Book;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.BeforeClass;
import org.junit.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;

public class BooksRESTTest {

    @BeforeClass
    public static void setup() {
        RestAssured.port = Integer.valueOf(8080);
        RestAssured.baseURI = "http://localhost";
        RestAssured.basePath = "";
    }

    @Test
    public void testGetOneBook() {
        // add the book to be fetched
        Book book = new Book("878","Book 123", 18.95, "Dip Das");
        given()
                .contentType("application/json")
                .body(book)
                .when().post("/books").then()
                .statusCode(200);
        // test getting the book
        given()
                .when()
                .get("books/878")
                .then()
                .contentType(ContentType.JSON)
                .and()
                .body("isbn",equalTo("878"))
                .body("title",equalTo("Book 123"))
                .body("price",equalTo(18.95f))
                .body("author",equalTo("Dip Das"));
        //cleanup
        given()
                .when()
                .delete("books/878");
    }
    @Test
    public void testBookDelete() {
        // add the book to be fetched
        Book book = new Book("878","Book 123", 18.95, "Dip Das");
        given()
                .contentType("application/json")
                .body(book)
                .when().post("/books").then()
                .statusCode(200);
        // test delete
        given()
                .when()
                .delete("books/878")
                .then()
                .statusCode(204);
        // getting the book
        given()
                .when()
                .get("books/878")
                .then()
                .statusCode(404);
    }

    @Test
    public void testAddBook() {
        // add the book
        Book book = new Book("878","Book 123", 18.95, "Dip Das");
        given()
                .contentType("application/json")
                .body(book)
                .when().post("/books").then()
                .statusCode(200);
        // getting the book
        given()
                .when()
                .get("books/878")
                .then()
                .contentType(ContentType.JSON)
                .and()
                .body("isbn",equalTo("878"))
                .body("title",equalTo("Book 123"))
                .body("price",equalTo(18.95f))
                .body("author",equalTo("Dip Das"));
        //cleanup
        given()
                .when()
                .delete("books/878");
    }

    @Test
    public void testGetAllBooks() {
        // add 2 books
        Book book1 = new Book("877","Book 1", 15.95, "Dip Das");
        Book book2 = new Book("878","Book 2", 17.95, "Abu Saleh");
        given()
                .contentType("application/json")
                .body(book1)
                .when().post("/books").then()
                .statusCode(200);

        given()
                .contentType("application/json")
                .body(book2)
                .when().post("/books").then()
                .statusCode(200);

        // read all books
        given()
                .when()
                .get("/books")
                .then()
                .contentType(ContentType.JSON)
                .and()
                .statusCode(200)
                .body("books[0].isbn", equalTo("877"))
                .body("books[1].isbn", equalTo("878"));

        //cleanup
        given()
                .when()
                .delete("books/877");

        given()
                .when()
                .delete("books/878");

    }


}
