package app;

import domain.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import repository.*;


import java.util.List;
import java.util.Optional;

@SpringBootApplication
@EnableJpaRepositories("repository")
@EntityScan("domain") 
public class Application implements CommandLineRunner{

	@Autowired
	OrderRepo orderRepo;

	@Autowired
	ProductRepo productRepo;

	@Autowired
	OrderLineRepo orderLineRepo;

	@Autowired
	CustomerRepo customerRepo;

	@Autowired
	AddressRepo addressRepo;

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		Product product = new Book("Java 7", "hello java", 44.00, "784675647");
		OrderLine orderline1 = new OrderLine(4, product);


		Product product2 = new CD("Akon alone", "lonelt", 20.09, "akon");
		OrderLine orderline2 = new OrderLine(4, product2);


		Product product3 = new DVD("The meg", "hunger shark", 39.99, "Action");
		OrderLine orderline3 = new OrderLine(4, product3);


		Order order1 = new Order("234743", "12/10/06", "open");
		order1.addOrderLine(orderline1);
		order1.addOrderLine(orderline2);
		order1.addOrderLine(orderline3);

		Customer customer1 = new Customer("Frank", "Brown");
		customer1.addOrder(order1);
		Address address = new Address("1000th", "iowa", "75674", "USA");
//		address.setCustomer(customer1);
		customer1.setAddress(address);
		order1.setCustomer(customer1);


//		addressRepo.save(address);
		customerRepo.save(customer1);
		orderRepo.save(order1);
		orderLineRepo.save(orderline1);
		productRepo.save(product);
		orderLineRepo.save(orderline2);
		productRepo.save(product2);
		orderLineRepo.save(orderline3);
		productRepo.save(product3);


		Optional<Order> orderOpt = orderRepo.findById(1L);
		Order order = orderOpt.get();
		printOrder(order);

		List<Customer> allCustomer = customerRepo.findAll();
		printCustomer(allCustomer);

		List<Product> filterProduct = productRepo.findProductLessThanPrice(DVD.class, 10);
		for(Product p : filterProduct){
			System.out.println("product detail : " + p.getName() + " " + p.getPrice());
		}


		List<Customer> customerFilterByLocation = customerRepo.findAllCustomersLocation("USA");
		printCustomer(customerFilterByLocation);

		List<Product> findCDFromArtist = productRepo.findCDFromArtist("akon");
		printProduct(findCDFromArtist);

		List<Order> statusFilterOrder = orderRepo.getOrdersByStatus("closed");
		System.out.println("Closed status order numbers ");
		for(Order o : statusFilterOrder ){
			System.out.println("Order number "+o.getOrdernr());
		}

		List<Address> findAddressByCountry = addressRepo.findAddressByCountry();
		findAddressByCountry.forEach(a-> System.out.println(a.toString()));

		List<Order> findOrderByCustomerCity = orderRepo.findOrderByCustomerCity("USA");
		for(Order o : findOrderByCustomerCity ){
			System.out.println("Order number by city "+o.getOrdernr());
		}
 	}

	public static void printCustomer(List<Customer> customers){
		for(Customer c : customers){
			System.out.println("customer name : " + c.getFirstname() + " " + c.getLastname() + " from " + c.getAddress().getCountry());
		}
	}
	public static void printOrder(Order order) {
		System.out.println("Order number: " + order.getOrdernr());
		System.out.println("Order date: " + order.getDate());
		System.out.println("Order status: " + order.getStatus());
		Customer cust = order.getCustomer();
		System.out.println("Customer: " + cust.getFirstname() + " "
				+ cust.getLastname());
		for (OrderLine orderline : order.getOrderlines()) {
			System.out.println("Orderline: quantity= "
					+ orderline.getQuantity());
			Product product = orderline.getProduct();
			System.out.println("Product: " + product.getName() + " "
					+ product.getDescription() + " " + product.getPrice());
		}

	}

	public static void printProduct(List<Product> products){
		for(Product p : products) {
			System.out.println("product name : " + p.getName() + " " + p.getPrice());
		}
	}
}
