package repository;

import domain.Order;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface OrderRepo extends JpaRepository<Order, Long> {
//    @Query("SELECT O from Order o WHERE o.status = Closed")
    List<Order> getOrdersByStatus(String status);

    @Query("SELECT o from Order o WHERE o.customer.address.city = :city")
    List<Order> findOrderByCustomerCity(@Param("city") String city);
}
