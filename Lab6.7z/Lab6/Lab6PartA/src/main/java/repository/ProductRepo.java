package repository;

import domain.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;


public interface ProductRepo extends JpaRepository<Product, Long> {

    @Query("SELECT p FROM Product p WHERE TYPE(p) = :byproduct AND p.price > :maxPrice")
    List<Product> findProductLessThanPrice(@Param("byproduct") Class byproduct, @Param("maxPrice") int maxPrice);

    @Query("SELECT p FROM Product p WHERE TYPE(p) = CD AND p.artist = :artist")
    List<Product> findCDFromArtist(@Param("artist") String artist);

    @Query("SELECT p FROM Product p WHERE TYPE(p) = CD AND p.artist = :artist AND p.price > :amount")
    List<Product> findCDFromArtistAnd(@Param("artist") String artist, @Param("amount") double amount);



//    @Query("SELECT p FROM Product p where TYPE(p) = :byproduct AND p.price > 10")
//    List<Product> findProductLessThanPrice(@Param("byproduct") String byproduct, @Param("price") int price);
//    @Query("SELECT p FROM Product p WHERE p.product_type= :product_type")
//    List<Product> findProductLessThanPrice(@Param("product_type") String product_type);
}
