package domain;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@Entity
public class Student {

    @Id
    @GeneratedValue()
    private long id;

    private String name;

    @OneToOne
    private Department department;


    @OneToMany
    private Collection<Grade> grade = new ArrayList<>();

    public Student() {
    }

    public Student(String name, Department department) {
        this.name = name;
        this.department = department;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public Collection<Grade> getGrade() {
        return grade;
    }

    public void setGrade(Collection<Grade> grade) {
        this.grade = grade;
    }

    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", department=" + department +
                ", grade=" + grade +
                '}';
    }
}
