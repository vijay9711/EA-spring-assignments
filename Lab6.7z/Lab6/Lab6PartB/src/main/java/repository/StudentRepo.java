package repository;

import domain.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface StudentRepo extends JpaRepository<Student, Long> {

    @Query("Select s from Student s Where s.department.name = :department")
    List<Student> findStudentByDepartment(@Param("department") String department);


    @Query("Select distinct s from Student s join fetch s.grade sg join fetch s.department where sg.course.name = :name")
    List<Student> getStudentByCourse(@Param("name") String name);
}
