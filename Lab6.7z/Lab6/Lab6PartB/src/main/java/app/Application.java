package app;


import domain.Course;
import domain.Department;
import domain.Grade;
import domain.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import repository.CourseRepo;
import repository.DepartmentRepo;
import repository.GradeRepo;
import repository.StudentRepo;


import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

@SpringBootApplication
@EnableJpaRepositories("repository")
@EntityScan("domain")
public class Application implements CommandLineRunner{
	@Autowired
	StudentRepo studentRepo;

	@Autowired
	CourseRepo courseRepo;

	@Autowired
	GradeRepo gradeRepo;

	@Autowired
	DepartmentRepo departmentRepo;

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		System.out.println("hello run ");


		Department d1 = new Department("IT");
		Department d2 = new Department("Civil");
		Department d3 = new Department("Aero");
		departmentRepo.save(d1);
		departmentRepo.save(d2);
		departmentRepo.save(d3);
		Course c1 = new Course("AI");
		Course c2 = new Course("CS");
		Course c3 = new Course("EA");
		courseRepo.save(c1);
		courseRepo.save(c2);
		courseRepo.save(c3);

		Grade g1 = new Grade(87);
		Grade g2 = new Grade(65);
		Grade g3 = new Grade(90);
		Grade g4 = new Grade(70);
		g1.setCourse(c1);
		g2.setCourse(c2);
		g3.setCourse(c3);
		List<Grade> lg = new ArrayList<Grade>();
		lg.add(g1);
		lg.add(g2);
		List<Grade> lg2 =new ArrayList<Grade>();
		lg2.add(g3);
		List<Grade> lg3 =new ArrayList<Grade>();
		lg3.add(g4);
		gradeRepo.save(g1);
		gradeRepo.save(g2);
		gradeRepo.save(g3);
		Student s1 = new Student("Mark", d1);
		Student s2 = new Student("Rick", d2);
		Student s3 = new Student("Ram", d3);

		studentRepo.save(s1);
		studentRepo.save(s2);
		studentRepo.save(s3);

		List<Student> sl = studentRepo.findStudentByDepartment("IT");
		sl.forEach(s->System.out.println(s.getName()));

		List<Student> slc = studentRepo.getStudentByCourse("EA");
		slc.forEach(s->System.out.println(s.getName()));
 	}
}
