package app;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import repository.*;
import domain.*;

import java.util.Optional;

@SpringBootApplication
@EnableJpaRepositories("repository")
@EntityScan("domain")
public class Application implements CommandLineRunner{
	
	@Autowired
	DepartmentRepository departmentRepository;
	@Autowired
	EmployeeRepository employeeRepository;
	@Autowired
	BookRepository bookRepository;
	@Autowired
	PassengerRepository passengerRepository;
	@Autowired
	SchoolRepository schoolRepository;

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		Department department = new Department("HR");
		Employee employee = new Employee(1, "John");
		department.addEmployee(employee);
		employee = new Employee(2, "Mike");
		department.addEmployee(employee);
		departmentRepository.save(department);


		System.out.println("\n\n############## Department Data ##############");
		// fetch all departments
		System.out.println("Departments found with findAll():");
		System.out.println("-------------------------------");
		for (Department dept : departmentRepository.findAll()) {
			System.out.println(dept);
		}
		System.out.println();


		Publisher publisher = new Publisher("12345");
		Book book = new Book(12345,"Java", "John");
		book.setPublisher(publisher);

		System.out.println("book - publisher: " + book);
		bookRepository.save(book);
		System.out.println("\n\n############## Book Data ##############");
		// fetch all books
		for (Book b : bookRepository.findAll()) {
			System.out.println(b);
		}

		// flight data
		Flight flight = new Flight("1005", "New York", "London", "2021-10-10");
		Passenger passenger = new Passenger("John");
		passenger.addFlight(flight);
		flight = new Flight("1001", "London", "Doha", "2021-12-10");
		passenger.addFlight(flight);
		flight = new Flight("1002", "Doha", "New York", "2021-13-20");
		passenger.addFlight(flight);
		passengerRepository.save(passenger);


		System.out.println("\n\n############## Flight Data ##############");
		// fetch all passengers
		for (Passenger p : passengerRepository.findAll()) {
			System.out.println(p);
		}


		// school data
		School school = new School("Maharishi International School");
		Student student = new Student("100001","Dip", "Ranjon");
		school.addStudent(student);
		student = new Student("100002", "Vijay", "Mano");
		school.addStudent(student);

		schoolRepository.save(school);

		System.out.println("\n\n############## School Data ##############");
		// fetch all schools
		for (School s : schoolRepository.findAll()) {
			System.out.println(s);
		}





	}

}
