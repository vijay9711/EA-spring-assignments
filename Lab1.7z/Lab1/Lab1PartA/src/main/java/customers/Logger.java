package customers;

public interface Logger {

    void log (String logstring);

}
