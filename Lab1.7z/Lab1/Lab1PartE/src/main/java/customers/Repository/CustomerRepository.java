package customers.Repository;

import customers.Entity.Customer;

public interface CustomerRepository {

	void save(Customer customer) ;

}
