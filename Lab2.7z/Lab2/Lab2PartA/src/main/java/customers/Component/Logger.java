package customers.Component;

public interface Logger {

    void log (String logstring);

}
