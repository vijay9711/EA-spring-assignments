package customers.Repository;

import customers.Entity.Customer;
import customers.Entity.Product;

public interface ProductRepository {

    void save(Product product);
}
